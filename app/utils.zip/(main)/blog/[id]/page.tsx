"use client";
import { notFound, useParams } from "next/navigation";
import BlogIdHero from "../../components/blogId/BlogIdHero";
import BlogIdContent from "../../components/blogId/BlogIdContent";
import ContactSection2 from "../../components/contact/ContactSection2";
import Contact from "../../components/home/Contact";

const BlogId = () => {
  const { id: blogId } = useParams();

  // If blog not found, show 404
  if (!blogId) {
    notFound();
  }
  return (
    <>
      <BlogIdHero currentBlogId={blogId} />
      <div className="bg-[#fffcfc] px-4 md:px-8 py-8 flex flex-col md:flex-row lg:justify-between gap-4">
        <BlogIdContent currentBlogId={blogId} />
        <div className="sticky top-8 h-fit lg:w-[30%]">
          <ContactSection2 />
        </div>
      </div>
      <Contact />
    </>
  );
};

export default BlogId;

// This file is deprecated - use BlogsSection instead
export { default } from "./blogs/BlogsSection";

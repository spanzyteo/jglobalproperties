"use client";

import ContactBody from "../components/contact/ContactBody";
import ContactHero from "../components/contact/ContactHero";

const Contact = () => {
  

  return (
   <>
    <ContactHero />
    <ContactBody />
   </>
  );
};

export default Contact;

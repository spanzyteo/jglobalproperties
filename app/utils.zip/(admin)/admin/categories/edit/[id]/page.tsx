/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import React from "react";
import { useParams } from "next/navigation";
import axios from "axios";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { MdArrowBack } from "react-icons/md";
import Loader from "@/app/components/shared/Loader";

const EditCategory = () => {
  const { id } = useParams();
  const router = useRouter();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);

  useEffect(() => {
    const fetchCategory = async () => {
      try {
        setFetchLoading(true);
        const response = await axios.get(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/categories/${id}`,
          {
            withCredentials: true,
          }
        );

        const { data } = response.data;

        // Set basic information
        setName(data.name || "");
        setDescription(data.description || "");

        setFetchLoading(false);
      } catch (error: any) {
        setFetchLoading(false);
        const message =
          error.response?.data?.message ||
          "An error occurred while fetching categories data";
        toast.error(message);
      }
    };

    if (id) {
      fetchCategory();
    }
  }, [id]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);

    try {
      const formData = new FormData();

      formData.append("name", name);
      formData.append("description", description);

      const response = await axios.patch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/categories/${id}`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );

      if (response.data.success) {
        toast.success("Category updated successfully!");
        router.push("/admin/categories");
      }

      setLoading(false);
    } catch (error: any) {
      setLoading(false);
      const message =
        error.response?.data?.message ||
        "An error occurred while updating the category";
      toast.error(message);
    }
  };

  if (fetchLoading) {
    return (
      <div className="bg-white min-h-screen w-full flex flex-col pb-12">
        <div className="xl:ml-108 mt-8 bg-[#F2F2F2] flex flex-col px-4 w-[90%] lg:w-194.25 rounded-xl mx-auto mb-8 pb-8">
          <div className="flex items-center justify-center py-16">
            <Loader />
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="bg-white min-h-screen w-full flex flex-col pb-12">
      <form onSubmit={handleSubmit}>
        <div className="xl:ml-108 mt-8 bg-[#F2F2F2] flex flex-col px-4 w-[90%] lg:w-194.25 rounded-xl mx-auto mb-8 pb-8">
          {/* Header */}
          <div className="mt-4 mb-6">
            <button
              type="button"
              onClick={() => router.back()}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-4"
            >
              <MdArrowBack className="h-5 w-5" />
              Back to Categories
            </button>
            <h1 className="text-xl font-semibold">Edit Category Information</h1>
          </div>

          {/* Basic Information */}
          <div className="space-y-6">
            {/* Name */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <h1 className="font-semibold text-[#4A5568] lg:w-32">Name</h1>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Category title"
                className="border border-[#EFEFEF] bg-[#F9F9F6] lg:w-134.75 w-full py-2.5 pl-3 focus:outline-none rounded-[5px] text-[#4A5568]"
                required
              />
            </div>

            {/* Description */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <h1 className="font-semibold text-[#4A5568] lg:w-32">
                Description
              </h1>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g., Victoria Island"
                className="border border-[#EFEFEF] bg-[#F9F9F6] lg:w-134.75 w-full py-2.5 pl-3 focus:outline-none rounded-[5px] text-[#4A5568]"
                required
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="xl:ml-108 flex justify-center xl:justify-start">
          <button
            type="submit"
            disabled={loading}
            className="bg-[#941A1A] flex items-center justify-center h-10 w-35 text-white rounded-[5px] mb-10 text-[14px] font-semibold hover:opacity-75 active:opacity-55 transition-all duration-500 ease-in-out cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Updating..." : "Update Category"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditCategory;
